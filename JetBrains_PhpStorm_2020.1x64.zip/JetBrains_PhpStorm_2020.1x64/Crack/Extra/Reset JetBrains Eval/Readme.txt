If need reset the eval in order, use this script and then use crack

