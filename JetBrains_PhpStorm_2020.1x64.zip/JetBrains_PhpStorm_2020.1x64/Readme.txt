- Install IDE and run it as Evaluate for free
- Deag & Drop "jetbrains-agent-latest.zip" file to IDE window
- Restart and install it as plungin
- DONE!

